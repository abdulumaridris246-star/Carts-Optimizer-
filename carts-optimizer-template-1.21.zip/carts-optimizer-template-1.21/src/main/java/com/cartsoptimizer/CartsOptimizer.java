package com.aniefr4g.cartsoptimizer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CartsOptimizer implements ClientModInitializer {

    private static KeyBinding keyBind;
    private static final Random RANDOM = new Random();

    @Override
    public void onInitializeClient() {

        keyBind = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.cartsoptimizer.activate",
                GLFW.GLFW_KEY_G,
                "category.cartsoptimizer"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (keyBind.wasPressed()) {
                placeRailAndTntCart(client);
            }
        });
    }

    private void placeRailAndTntCart(MinecraftClient client) {
        if (client.player == null || client.world == null) return;

        BlockHitResult hit = (BlockHitResult) client.crosshairTarget;
        if (hit == null) return;

        BlockPos pos = hit.getBlockPos();
        World world = client.world;

        BlockState state = world.getBlockState(pos);
        Block block = state.getBlock();

        // ANY TYPE OF RAIL CHECK
        if (!block.getName().getString().toLowerCase().contains("rail")) return;

        int railSlot = getRandomSlotWithItem(client, Items.RAIL);
        int tntCartSlot = getRandomSlotWithItem(client, Items.TNT_MINECART);

        if (railSlot == -1 || tntCartSlot == -1) return;

        // Switch to rail
        client.player.getInventory().selectedSlot = railSlot;
        client.interactionManager.interactBlock(
                client.player,
                Hand.MAIN_HAND,
                hit
        );

        // Switch to TNT minecart
        client.player.getInventory().selectedSlot = tntCartSlot;

        BlockPos spawnPos = pos.offset(Direction.UP);
        TntMinecartEntity cart = new TntMinecartEntity(
                world,
                spawnPos.getX() + 0.5,
                spawnPos.getY() + 0.5,
                spawnPos.getZ() + 0.5
        );

        world.spawnEntity(cart);
    }

    private int getRandomSlotWithItem(MinecraftClient client, net.minecraft.item.Item item) {
        List<Integer> slots = new ArrayList<>();

        for (int i = 0; i < 9; i++) { // hotbar only
            ItemStack stack = client.player.getInventory().getStack(i);
            if (stack.getItem() == item) {
                slots.add(i);
            }
        }

        if (slots.isEmpty()) return -1;
        return slots.get(RANDOM.nextInt(slots.size()));
    }
}