package com.easystunslams.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;

public class EasyStunSlamsClient implements ClientModInitializer {

    private static LivingEntity pendingTarget;
    private static int maceSlot;
    private static int previousSlot;
    private static boolean waitingForMace;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;

            // Tick 1: mace hit
            if (waitingForMace && pendingTarget != null) {
                client.player.getInventory().selectedSlot = maceSlot;
                client.interactionManager.attackEntity(client.player, pendingTarget);
                client.player.getInventory().selectedSlot = previousSlot;

                waitingForMace = false;
                pendingTarget = null;
                return;
            }

            // Tick 0: axe hit (left-click hold)
            if (client.options.attackKey.isPressed() && canAttack(client)) {
                tryStunSlam(client);
            }
        });
    }

    private static void tryStunSlam(MinecraftClient client) {
        if (!(client.crosshairTarget instanceof EntityHitResult ehr)) return;
        if (!(ehr.getEntity() instanceof LivingEntity target)) return;
        if (!target.isBlocking()) return;
        if (client.player.isOnGround()) return;

        int axeSlot = findItemSlot(Items.DIAMOND_AXE);
        int maceSlotLocal = findItemSlot(Items.MACE);
        if (axeSlot == -1 || maceSlotLocal == -1) return;

        previousSlot = client.player.getInventory().selectedSlot;

        // Axe hit (tick 0)
        client.player.getInventory().selectedSlot = axeSlot;
        client.interactionManager.attackEntity(client.player, target);

        // Prepare mace for next tick
        pendingTarget = target;
        maceSlot = maceSlotLocal;
        waitingForMace = true;
    }

    private static boolean canAttack(MinecraftClient client) {
        return client.player.getAttackCooldownProgress(0.0f) >= 1.0f;
    }

    private static int findItemSlot(net.minecraft.item.Item item) {
        var inv = MinecraftClient.getInstance().player.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).getItem() == item) return i;
        }
        return -1;
    }
}
